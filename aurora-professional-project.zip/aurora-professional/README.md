# Aurora Professional Project

Aurora is a professional smart city / eco-tourism web app prototype for Ifrane, Morocco. It includes login, live dashboard, road status, weather risk, alert notifications, community reporting, and admin moderation.

## Demo accounts

| Role | Email | Password |
|---|---|---|
| Resident | ayman@aurora.ma | 123456 |
| Tourist | tourist@aurora.ma | 123456 |
| Admin | admin@aurora.ma | admin123 |

## How to run in VS Code

1. Unzip the project.
2. Open the folder `aurora-professional` in VS Code.
3. Open the terminal in VS Code.
4. Run:

```bash
npm install
npm run dev
```

5. Open the link shown in the terminal, usually:

```bash
http://localhost:5173
```

## Pages included

- Login screen
- Dashboard
- Live Map mockup
- Reports page
- Notifications page
- Admin moderation panel

## Notes

This is a front-end prototype using React + TypeScript + Vite. The data is mocked locally so the project runs without a backend. For a production version, connect the app to Node.js/Express, MongoDB, OpenWeatherMap API, and Google Maps API.
