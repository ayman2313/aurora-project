export type Role = 'Resident' | 'Tourist' | 'Admin';
export type Severity = 'Low' | 'Medium' | 'High' | 'Critical';
export type ReportStatus = 'Pending' | 'Verified' | 'Rejected';

export interface User {
  name: string;
  email: string;
  password: string;
  role: Role;
}

export interface Alert {
  id: number;
  title: string;
  zone: string;
  severity: Severity;
  time: string;
  description: string;
}

export interface RoadStatus {
  id: number;
  route: string;
  status: 'Open' | 'Caution' | 'Closed';
  condition: string;
  eta: string;
  confidence: number;
}

export interface Report {
  id: number;
  reporter: string;
  type: string;
  location: string;
  urgency: Severity;
  status: ReportStatus;
  description: string;
  time: string;
}

export const users: User[] = [
  { name: 'Ayman Massaoudi', email: 'ayman@aurora.ma', password: '123456', role: 'Resident' },
  { name: 'Tourist Demo', email: 'tourist@aurora.ma', password: '123456', role: 'Tourist' },
  { name: 'Aurora Admin', email: 'admin@aurora.ma', password: 'admin123', role: 'Admin' }
];

export const alerts: Alert[] = [
  {
    id: 1,
    title: 'Snow expected near Michlifen',
    zone: 'Michlifen Road',
    severity: 'High',
    time: '12 min ago',
    description: 'Reduced visibility and slippery road conditions reported by verified users.'
  },
  {
    id: 2,
    title: 'Forest access limited',
    zone: 'Cedar Forest',
    severity: 'Medium',
    time: '28 min ago',
    description: 'Access remains possible, but parking areas are nearly full.'
  },
  {
    id: 3,
    title: 'City center roads open',
    zone: 'Ifrane Center',
    severity: 'Low',
    time: '45 min ago',
    description: 'Traffic is normal and public roads are accessible.'
  }
];

export const roadStatuses: RoadStatus[] = [
  { id: 1, route: 'Ifrane → Michlifen', status: 'Caution', condition: 'Snow patches, low visibility', eta: '+18 min delay', confidence: 88 },
  { id: 2, route: 'Ifrane → Azrou', status: 'Open', condition: 'Normal traffic', eta: 'No delay', confidence: 96 },
  { id: 3, route: 'Cedar Forest Access', status: 'Closed', condition: 'Temporary closure for safety', eta: 'Unknown', confidence: 91 },
  { id: 4, route: 'AUI → City Center', status: 'Open', condition: 'Clear road', eta: 'No delay', confidence: 99 }
];

export const initialReports: Report[] = [
  {
    id: 101,
    reporter: 'Resident user',
    type: 'Road Hazard',
    location: 'Route to Michlifen',
    urgency: 'High',
    status: 'Verified',
    description: 'Ice forming on the right lane after the hill curve.',
    time: '09:20'
  },
  {
    id: 102,
    reporter: 'Tourist user',
    type: 'Environmental Observation',
    location: 'Cedar Forest entrance',
    urgency: 'Medium',
    status: 'Pending',
    description: 'Heavy crowding near parking area and blocked access path.',
    time: '10:05'
  },
  {
    id: 103,
    reporter: 'Resident user',
    type: 'Weather Hazard',
    location: 'Ifrane Center',
    urgency: 'Low',
    status: 'Pending',
    description: 'Light rain started near the main square.',
    time: '10:40'
  }
];

export const weatherSummary = {
  temperature: '2°C',
  condition: 'Cloudy with snow risk',
  wind: '18 km/h',
  visibility: 'Moderate',
  riskScore: 72
};
