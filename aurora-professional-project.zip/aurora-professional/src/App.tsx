import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  Bell,
  CheckCircle2,
  CloudSnow,
  Compass,
  Gauge,
  LayoutDashboard,
  Lock,
  LogOut,
  MapPin,
  Menu,
  Navigation,
  Plus,
  ShieldCheck,
  Snowflake,
  UserRound,
  X
} from 'lucide-react';
import { alerts, initialReports, roadStatuses, users, weatherSummary, type Report, type User } from './data/mockData';

type Page = 'dashboard' | 'map' | 'reports' | 'notifications' | 'admin';

type NewReport = {
  type: string;
  location: string;
  urgency: Report['urgency'];
  description: string;
};

const emptyReport: NewReport = {
  type: 'Road Hazard',
  location: '',
  urgency: 'Medium',
  description: ''
};

function statusClass(value: string) {
  return value.toLowerCase().replaceAll(' ', '-');
}

function LoginScreen({ onLogin }: { onLogin: (user: User) => void }) {
  const [email, setEmail] = useState('ayman@aurora.ma');
  const [password, setPassword] = useState('123456');
  const [error, setError] = useState('');

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const user = users.find(
      (account) => account.email.toLowerCase() === email.toLowerCase() && account.password === password
    );

    if (!user) {
      setError('Invalid email or password. Use one of the demo accounts below.');
      return;
    }

    setError('');
    onLogin(user);
  };

  return (
    <main className="login-page">
      <section className="login-hero">
        <div className="brand-mark"><Snowflake size={34} /></div>
        <p className="eyebrow">Smart City / Eco-Tourism Platform</p>
        <h1>Aurora keeps Ifrane moving safely.</h1>
        <p>
          Live road conditions, weather risks, local reports, and verified alerts in one clean professional dashboard.
        </p>
        <div className="hero-grid">
          <div><strong>99%</strong><span>Target uptime</span></div>
          <div><strong>2s</strong><span>Fast interface goal</span></div>
          <div><strong>24/7</strong><span>Alert monitoring</span></div>
        </div>
      </section>

      <section className="login-card">
        <div className="card-header">
          <div>
            <p className="eyebrow">Welcome back</p>
            <h2>Login to Aurora</h2>
          </div>
          <Lock className="muted-icon" />
        </div>

        <form onSubmit={handleSubmit} className="form">
          <label>
            Email
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" placeholder="name@aurora.ma" />
          </label>
          <label>
            Password
            <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" placeholder="Password" />
          </label>
          {error && <p className="error-message">{error}</p>}
          <button className="primary-button" type="submit">Login</button>
        </form>

        <div className="demo-accounts">
          <p>Demo accounts</p>
          <button onClick={() => { setEmail('ayman@aurora.ma'); setPassword('123456'); }}>Resident</button>
          <button onClick={() => { setEmail('tourist@aurora.ma'); setPassword('123456'); }}>Tourist</button>
          <button onClick={() => { setEmail('admin@aurora.ma'); setPassword('admin123'); }}>Admin</button>
        </div>
      </section>
    </main>
  );
}

function Sidebar({ currentPage, setPage, user, onLogout }: { currentPage: Page; setPage: (page: Page) => void; user: User; onLogout: () => void }) {
  const [open, setOpen] = useState(false);
  const items: { page: Page; label: string; icon: React.ReactNode; adminOnly?: boolean }[] = [
    { page: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={19} /> },
    { page: 'map', label: 'Live Map', icon: <MapPin size={19} /> },
    { page: 'reports', label: 'Reports', icon: <Plus size={19} /> },
    { page: 'notifications', label: 'Notifications', icon: <Bell size={19} /> },
    { page: 'admin', label: 'Admin Panel', icon: <ShieldCheck size={19} />, adminOnly: true }
  ];

  return (
    <>
      <button className="mobile-menu" onClick={() => setOpen(true)}><Menu /></button>
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <button className="close-menu" onClick={() => setOpen(false)}><X /></button>
        <div className="logo-row">
          <div className="brand-mark small"><Snowflake size={22} /></div>
          <div>
            <strong>Aurora</strong>
            <span>Ifrane Smart Mobility</span>
          </div>
        </div>

        <nav>
          {items
            .filter((item) => !item.adminOnly || user.role === 'Admin')
            .map((item) => (
              <button
                key={item.page}
                className={currentPage === item.page ? 'active' : ''}
                onClick={() => { setPage(item.page); setOpen(false); }}
              >
                {item.icon}{item.label}
              </button>
            ))}
        </nav>

        <div className="user-box">
          <div className="avatar"><UserRound size={20} /></div>
          <div>
            <strong>{user.name}</strong>
            <span>{user.role}</span>
          </div>
        </div>
        <button className="logout" onClick={onLogout}><LogOut size={18} /> Logout</button>
      </aside>
      {open && <div className="overlay" onClick={() => setOpen(false)} />}
    </>
  );
}

function StatCard({ icon, label, value, note }: { icon: React.ReactNode; label: string; value: string; note: string }) {
  return (
    <div className="stat-card">
      <div className="stat-icon">{icon}</div>
      <p>{label}</p>
      <h3>{value}</h3>
      <span>{note}</span>
    </div>
  );
}

function Dashboard({ user, reports }: { user: User; reports: Report[] }) {
  const pendingReports = reports.filter((report) => report.status === 'Pending').length;
  const closedRoads = roadStatuses.filter((road) => road.status === 'Closed').length;

  return (
    <section className="page-content">
      <div className="top-section">
        <div>
          <p className="eyebrow">Live situation center</p>
          <h1>Good evening, {user.name.split(' ')[0]}</h1>
          <p className="subtext">Monitor road accessibility, weather hazards, community reports, and urgent alerts for Ifrane.</p>
        </div>
        <div className="weather-pill"><CloudSnow size={20} /> {weatherSummary.condition}</div>
      </div>

      <div className="stats-grid">
        <StatCard icon={<Gauge />} label="Risk score" value={`${weatherSummary.riskScore}%`} note="Winter mobility risk" />
        <StatCard icon={<Navigation />} label="Roads closed" value={`${closedRoads}`} note="Verified route restrictions" />
        <StatCard icon={<AlertTriangle />} label="Pending reports" value={`${pendingReports}`} note="Need admin review" />
        <StatCard icon={<CheckCircle2 />} label="Confidence" value="92%" note="API + community signals" />
      </div>

      <div className="dashboard-grid">
        <div className="panel large-panel">
          <div className="panel-title">
            <h2>Road condition overview</h2>
            <span>Updated now</span>
          </div>
          <div className="road-list">
            {roadStatuses.map((road) => (
              <div className="road-item" key={road.id}>
                <div>
                  <strong>{road.route}</strong>
                  <span>{road.condition}</span>
                </div>
                <div className="road-meta">
                  <span className={`badge ${statusClass(road.status)}`}>{road.status}</span>
                  <small>{road.eta}</small>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="panel">
          <div className="panel-title">
            <h2>Weather details</h2>
            <span>Ifrane</span>
          </div>
          <div className="weather-card">
            <CloudSnow size={54} />
            <h3>{weatherSummary.temperature}</h3>
            <p>{weatherSummary.condition}</p>
            <div className="mini-grid">
              <div><span>Wind</span><strong>{weatherSummary.wind}</strong></div>
              <div><span>Visibility</span><strong>{weatherSummary.visibility}</strong></div>
            </div>
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-title">
          <h2>Urgent alerts</h2>
          <span>{alerts.length} active</span>
        </div>
        <div className="alert-grid">
          {alerts.map((alert) => (
            <article className="alert-card" key={alert.id}>
              <span className={`badge ${statusClass(alert.severity)}`}>{alert.severity}</span>
              <h3>{alert.title}</h3>
              <p>{alert.description}</p>
              <small>{alert.zone} · {alert.time}</small>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function MapView() {
  return (
    <section className="page-content">
      <div className="top-section">
        <div>
          <p className="eyebrow">Interactive condition map</p>
          <h1>Live Map</h1>
          <p className="subtext">Map-style preview showing hazard markers, closures, and important travel zones.</p>
        </div>
      </div>
      <div className="map-layout">
        <div className="map-panel">
          <div className="map-background">
            <div className="route-line one" />
            <div className="route-line two" />
            <div className="marker critical" style={{ top: '26%', left: '64%' }}><AlertTriangle size={18} /></div>
            <div className="marker medium" style={{ top: '58%', left: '42%' }}><MapPin size={18} /></div>
            <div className="marker good" style={{ top: '42%', left: '18%' }}><CheckCircle2 size={18} /></div>
            <div className="map-label center">Ifrane Center</div>
            <div className="map-label michlifen">Michlifen</div>
            <div className="map-label cedar">Cedar Forest</div>
          </div>
        </div>
        <div className="panel map-side">
          <h2>Map legend</h2>
          <div className="legend-row"><span className="dot critical" /> Critical hazard</div>
          <div className="legend-row"><span className="dot medium" /> Caution / report</div>
          <div className="legend-row"><span className="dot good" /> Safe / open</div>
          <p className="subtext">This project uses a polished map mockup. In production, connect it to Google Maps API or Mapbox.</p>
        </div>
      </div>
    </section>
  );
}

function Reports({ reports, addReport }: { reports: Report[]; addReport: (report: NewReport) => void }) {
  const [form, setForm] = useState<NewReport>(emptyReport);
  const [success, setSuccess] = useState('');

  const submitReport = (event: React.FormEvent) => {
    event.preventDefault();
    if (!form.location.trim() || !form.description.trim()) return;
    addReport(form);
    setForm(emptyReport);
    setSuccess('Report submitted successfully and sent to admin moderation.');
    window.setTimeout(() => setSuccess(''), 2500);
  };

  return (
    <section className="page-content">
      <div className="top-section">
        <div>
          <p className="eyebrow">Community reporting</p>
          <h1>Submit & track reports</h1>
          <p className="subtext">Residents and tourists can report road issues, weather hazards, or environmental observations.</p>
        </div>
      </div>
      <div className="reports-layout">
        <form className="panel form report-form" onSubmit={submitReport}>
          <h2>New report</h2>
          <label>Type
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              <option>Road Hazard</option>
              <option>Weather Hazard</option>
              <option>Environmental Observation</option>
              <option>Traffic Issue</option>
            </select>
          </label>
          <label>Location
            <input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} placeholder="Example: Michlifen Road" />
          </label>
          <label>Urgency
            <select value={form.urgency} onChange={(e) => setForm({ ...form, urgency: e.target.value as Report['urgency'] })}>
              <option>Low</option>
              <option>Medium</option>
              <option>High</option>
              <option>Critical</option>
            </select>
          </label>
          <label>Description
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Describe what happened clearly" />
          </label>
          {success && <p className="success-message">{success}</p>}
          <button className="primary-button" type="submit">Submit report</button>
        </form>

        <div className="panel">
          <div className="panel-title">
            <h2>Recent reports</h2>
            <span>{reports.length} total</span>
          </div>
          <div className="report-list">
            {reports.map((report) => (
              <article className="report-item" key={report.id}>
                <div>
                  <strong>{report.type}</strong>
                  <p>{report.description}</p>
                  <small>{report.location} · {report.time}</small>
                </div>
                <span className={`badge ${statusClass(report.status)}`}>{report.status}</span>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function Notifications() {
  return (
    <section className="page-content">
      <div className="top-section">
        <div>
          <p className="eyebrow">Safety notifications</p>
          <h1>Notifications</h1>
          <p className="subtext">Urgent alerts, timestamps, affected areas, and short condition summaries.</p>
        </div>
      </div>
      <div className="notification-list">
        {alerts.map((alert) => (
          <div className="notification-card" key={alert.id}>
            <div className="notification-icon"><Bell size={20} /></div>
            <div>
              <div className="notification-title"><strong>{alert.title}</strong><span>{alert.time}</span></div>
              <p>{alert.description}</p>
              <small>{alert.zone}</small>
            </div>
            <span className={`badge ${statusClass(alert.severity)}`}>{alert.severity}</span>
          </div>
        ))}
      </div>
    </section>
  );
}

function AdminPanel({ reports, updateReport }: { reports: Report[]; updateReport: (id: number, status: Report['status']) => void }) {
  const pending = useMemo(() => reports.filter((report) => report.status === 'Pending'), [reports]);

  return (
    <section className="page-content">
      <div className="top-section">
        <div>
          <p className="eyebrow">Admin moderation</p>
          <h1>Admin Panel</h1>
          <p className="subtext">Review community reports, verify useful information, and reject unreliable submissions.</p>
        </div>
      </div>
      <div className="panel">
        <div className="panel-title">
          <h2>Reports waiting for review</h2>
          <span>{pending.length} pending</span>
        </div>
        <div className="admin-table">
          {reports.map((report) => (
            <div className="admin-row" key={report.id}>
              <div>
                <strong>{report.type}</strong>
                <p>{report.description}</p>
                <small>{report.location} · {report.reporter} · {report.time}</small>
              </div>
              <span className={`badge ${statusClass(report.urgency)}`}>{report.urgency}</span>
              <span className={`badge ${statusClass(report.status)}`}>{report.status}</span>
              <div className="admin-actions">
                <button onClick={() => updateReport(report.id, 'Verified')}>Verify</button>
                <button onClick={() => updateReport(report.id, 'Rejected')}>Reject</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function App() {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('aurora-user');
    return stored ? JSON.parse(stored) : null;
  });
  const [page, setPage] = useState<Page>('dashboard');
  const [reports, setReports] = useState<Report[]>(initialReports);

  const handleLogin = (account: User) => {
    localStorage.setItem('aurora-user', JSON.stringify(account));
    setUser(account);
    setPage('dashboard');
  };

  const handleLogout = () => {
    localStorage.removeItem('aurora-user');
    setUser(null);
  };

  const addReport = (report: NewReport) => {
    const newReport: Report = {
      id: Date.now(),
      reporter: user?.name ?? 'Guest user',
      type: report.type,
      location: report.location,
      urgency: report.urgency,
      status: 'Pending',
      description: report.description,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    setReports((current) => [newReport, ...current]);
  };

  const updateReport = (id: number, status: Report['status']) => {
    setReports((current) => current.map((report) => report.id === id ? { ...report, status } : report));
  };

  if (!user) return <LoginScreen onLogin={handleLogin} />;

  return (
    <div className="app-shell">
      <Sidebar currentPage={page} setPage={setPage} user={user} onLogout={handleLogout} />
      <main className="main-area">
        {page === 'dashboard' && <Dashboard user={user} reports={reports} />}
        {page === 'map' && <MapView />}
        {page === 'reports' && <Reports reports={reports} addReport={addReport} />}
        {page === 'notifications' && <Notifications />}
        {page === 'admin' && user.role === 'Admin' && <AdminPanel reports={reports} updateReport={updateReport} />}
      </main>
    </div>
  );
}
